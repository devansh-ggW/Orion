const fs = require('fs');
const vm = require('vm');

const sandbox = { console, setTimeout, window: {} };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync('engine.js', 'utf8'), sandbox);
const engine = sandbox.window.OrionEngine;

function assert(ok, message) {
  if (!ok) throw new Error(message);
}

(async () => {
  assert(engine.RULES.length >= 90, `Expected 90+ rules, got ${engine.RULES.length}`);
  const bad = engine.makeTestProject();
  const result = await engine.scan(bad, () => {});
  const ids = new Set(result.findings.map(f => f.id));
  for (const id of ['DOM-XSS-001', 'AUTH-001', 'COOKIE-001', 'INJECT-SQL-001']) {
    assert(ids.has(id), `Missing expected finding ${id}`);
  }
  assert(result.findings.some(f => f.severity === 'high'), 'Expected high-risk findings');
  assert(!result.findings.some(f => f.id === 'CSRF-001' && f.file.includes('public/')), 'CSRF should not be emitted for frontend fetch calls');

  const safe = [
    { path:'site/index.html', name:'index.html', size:100, text:'<!doctype html><html><head><meta name="referrer" content="strict-origin-when-cross-origin"><meta http-equiv="Content-Security-Policy" content="default-src \'self\'"></head><body><a href="https://example.org" target="_blank" rel="noopener">x</a><a href="/privacy">Privacy Policy</a></body></html>' },
    { path:'site/app.js', name:'app.js', size:100, text:'document.querySelector("#name").textContent = "hello";' },
    { path:'site/package.json', name:'package.json', size:100, text:'{"dependencies":{"demo":"1.0.0"}}' },
    { path:'site/package-lock.json', name:'package-lock.json', size:100, text:'{}' }
  ];
  const safeResult = await engine.scan(safe, () => {});
  assert(!safeResult.findings.some(f => f.id === 'DOM-XSS-001'), 'Safe fixture triggered DOM-XSS-001');
  assert(!safeResult.findings.some(f => f.id === 'HTML-003'), 'Safe fixture triggered HTML-003');

  const upload = [{path:'upload/server.py',name:'server.py',size:100,text:"from flask import request\n@app.post('/upload')\ndef upload():\n    f=request.files['file']\n    path = ROOT / f.filename\n    path.write_bytes(f.read())"}];
  const uploadResult = await engine.scan(upload, () => {});
  assert(uploadResult.findings.some(f => f.id === 'UPLOAD-001'), 'Expected upload sink finding');
  assert(uploadResult.findings.some(f => f.id === 'PATH-002'), 'Expected original filename path finding');
  assert(uploadResult.findings.filter(f => f.id === 'UPLOAD-001').length === 1, 'Upload finding should not duplicate across directory setup lines');

  const cleanUpload = [{path:'upload/server.py',name:'server.py',size:100,text:"ALLOWED={'image/png','image/jpeg'}\nf=request.files['file']\nif f.mimetype not in ALLOWED: abort(400)\nf.save('/safe-store/'+uuid4().hex)"}];
  const cleanUploadResult = await engine.scan(cleanUpload, () => {});
  assert(!cleanUploadResult.findings.some(f => f.id === 'UPLOAD-001'), 'Validated upload fixture triggered upload finding');

  const csrf = [{path:'app/server.js',name:'server.js',size:100,text:"app.post('/change', handler); res.setHeader('Set-Cookie','session=abc');"},{path:'app/index.html',name:'index.html',size:50,text:'<html><head></head><body></body></html>'}];
  const csrfResult = await engine.scan(csrf, () => {});
  assert(csrfResult.findings.filter(f => f.id === 'CSRF-001').length === 1, 'CSRF should be a single project-level finding');
  const rooted = [
    {path:'CinderClip/public/index.html',name:'index.html',size:10,text:'<html></html>'},
    {path:'CinderClip/server.py',name:'server.py',size:10,text:'print(1)'},
    {path:'CinderClip/server.py',name:'server.py',size:10,text:'print(1)'}
  ];
  const canonical = engine.canonicalizeFiles(rooted);
  assert(canonical.length === 2, 'Canonicalization should remove duplicate files');
  assert(canonical.some(f => f.path === 'public/index.html'), 'Canonicalization should strip a single archive root');

  const mirrored = [
    {path:'README.md',name:'README.md',size:10,text:'same'},
    {path:'server.py',name:'server.py',size:20,text:'print(1)'},
    {path:'CinderClip/README.md',name:'README.md',size:10,text:'same'},
    {path:'CinderClip/server.py',name:'server.py',size:20,text:'print(1)'}
  ];
  const collapsed = engine.canonicalizeFiles(mirrored);
  assert(collapsed.length === 2, 'Mirrored archive root was not collapsed');

  const sanitizedUpload = [{path:'app/server.py',name:'server.py',size:100,text:`def safe_filename(original):\n    return basename(original).replace('..','')\n\nsource_stem = safe_filename(original)\nname = f"uploads/{source_stem}"\nwrite_bytes(data)` }];
  const sanitizedUploadResult = await engine.scan(sanitizedUpload, () => {});
  assert(!sanitizedUploadResult.findings.some(f => f.id === 'PATH-002'), 'Sanitized filename fixture triggered PATH-002');

  console.log(`PASS · ${engine.RULES.length} rules · bad=${result.findings.length} findings · safe=${safeResult.findings.length} low-context advisories`);
})();


